"""Utilities related archives.
"""

from __future__ import absolute_import

import logging
import os
import posixpath
import shutil
import stat
import tarfile
import zipfile

from pip._internal.exceptions import InstallationError
from pip._internal.utils.filetypes import (
    BZ2_EXTENSIONS,
    TAR_EXTENSIONS,
    XZ_EXTENSIONS,
    ZIP_EXTENSIONS,
)
from pip._internal.utils.misc import ensure_dir
from pip._internal.utils.typing import MYPY_CHECK_RUNNING

if MYPY_CHECK_RUNNING:
    from typing import Iterable, List, Optional, Set, Text, Union
    from zipfile import ZipInfo


logger = logging.getLogger(__name__)


SUPPORTED_EXTENSIONS = ZIP_EXTENSIONS + TAR_EXTENSIONS

try:
    import bz2  # noqa
    SUPPORTED_EXTENSIONS += BZ2_EXTENSIONS
except ImportError:
    logger.debug('bz2 module is not available')

try:
    # Only for Python 3.3+
    import lzma  # noqa
    SUPPORTED_EXTENSIONS += XZ_EXTENSIONS
except ImportError:
    logger.debug('lzma module is not available')


def current_umask():
    # type: () -> int
    """Get the current umask which involves having to set it temporarily."""
    mask = os.umask(0)
    os.umask(mask)
    return mask


def split_leading_dir(path):
    # type: (Union[str, Text]) -> List[Union[str, Text]]
    path = path.lstrip('/').lstrip('\\')
    if (
        '/' in path and (
            ('\\' in path and path.find('/') < path.find('\\')) or
            '\\' not in path
        )
    ):
        return path.split('/', 1)
    elif '\\' in path:
        return path.split('\\', 1)
    else:
        return [path, '']


def has_leading_dir(paths):
    # type: (Iterable[Union[str, Text]]) -> bool
    """Returns true if all the paths have the same leading path name
    (i.e., everything is in one subdirectory in an archive)"""
    common_prefix = None
    for path in paths:
        prefix, rest = split_leading_dir(path)
        if not prefix:
            return False
        elif common_prefix is None:
            common_prefix = prefix
        elif prefix != common_prefix:
            return False
    return True


def is_within_directory(directory, target, resolve_symlinks=False):
    # type: ((Union[str, Text]), (Union[str, Text]), bool) -> bool
    """
    Return true if the absolute path of target is within the directory
    (including when target is equal to the directory).

    When ``resolve_symlinks`` is true, resolve symlinks before comparing so
    traversal through a symlink (e.g. "link/../file") is also caught.
    """
    if resolve_symlinks:
        abs_directory = os.path.realpath(directory)
        abs_target = os.path.realpath(target)
    else:
        abs_directory = os.path.abspath(directory)
        abs_target = os.path.abspath(target)

    # NOTE: os.path.commonprefix compares character-by-character, so it treats
    #       "/a/parent" and "/a/parentfoo" as sharing the prefix "/a/parent"
    #       and would report the latter as "within" the former (CVE-2026-1703).
    #       os.path.commonpath compares on path components but is unavailable on
    #       Python 2.7 (and drops a POSIX "//" prefix), so enforce a component
    #       boundary explicitly instead.
    if abs_target == abs_directory:
        return True
    # A filesystem root ("/" or "C:\\") already ends with a separator;
    # appending another would reject everything.
    if abs_directory.endswith(os.sep):
        prefix = abs_directory
    else:
        prefix = abs_directory + os.sep
    return abs_target.startswith(prefix)


def _tar_member_paths(tar):
    # type: (tarfile.TarFile) -> Set[str]
    """Normalized member paths plus every implied parent directory."""
    paths = set()  # type: Set[str]
    for member in tar.getmembers():
        name = posixpath.normpath(member.name.replace("\\", "/"))
        if name == ".":
            # An explicit "." / "./" member is the archive root. Record it so a
            # symlink resolving to the root (e.g. "./sub/root -> ..") is found,
            # as tar.getmember(".") did. The root is never added implicitly.
            paths.add(name)
            continue
        while name not in ("", ".", "/"):
            paths.add(name)
            parent = posixpath.dirname(name)
            if parent == name:
                # posixpath.dirname("//") == "//": stop at any fixed point.
                break
            name = parent
    return paths


def is_symlink_target_in_tar(tar, tarinfo, member_paths=None):
    # type: (tarfile.TarFile, tarfile.TarInfo, Optional[Set[str]]) -> bool
    """
    Return true if the file the symlink member points to is itself a member
    of the same tar archive, i.e. the symlink does not escape the archive to
    reference an arbitrary path on the host filesystem (CVE-2025-8869).

    Member names are compared after normalization, and directories implied
    by a member's path count as members, so "./"-prefixed archives and links
    to a directory without its own entry are accepted. Containment itself is
    enforced by the realpath checks in untar_file().
    """
    linkname = os.path.join(os.path.dirname(tarinfo.name), tarinfo.linkname)
    linkname = posixpath.normpath(linkname.replace("\\", "/"))
    if member_paths is None:
        member_paths = _tar_member_paths(tar)
    return linkname in member_paths


def set_extracted_file_to_default_mode_plus_executable(path):
    # type: (Union[str, Text]) -> None
    """
    Make file present at path have execute for user/group/world
    (chmod +x) is no-op on windows per python docs
    """
    os.chmod(path, (0o777 & ~current_umask() | 0o111))


def zip_item_is_executable(info):
    # type: (ZipInfo) -> bool
    mode = info.external_attr >> 16
    # if mode and regular file and any execute permissions for
    # user/group/world?
    return bool(mode and stat.S_ISREG(mode) and mode & 0o111)


def unzip_file(filename, location, flatten=True):
    # type: (str, str, bool) -> None
    """
    Unzip the file (with path `filename`) to the destination `location`.  All
    files are written based on system defaults and umask (i.e. permissions are
    not preserved), except that regular file members with any execute
    permissions (user, group, or world) have "chmod +x" applied after being
    written. Note that for windows, any execute changes using os.chmod are
    no-ops per the python docs.
    """
    ensure_dir(location)
    zipfp = open(filename, 'rb')
    try:
        zip = zipfile.ZipFile(zipfp, allowZip64=True)
        leading = has_leading_dir(zip.namelist()) and flatten
        for info in zip.infolist():
            name = info.filename
            fn = name
            if leading:
                fn = split_leading_dir(name)[1]
            fn = os.path.join(location, fn)
            dir = os.path.dirname(fn)
            if not is_within_directory(location, fn):
                message = (
                    'The zip file ({}) has a file ({}) trying to install '
                    'outside target directory ({})'
                )
                raise InstallationError(message.format(filename, fn, location))
            if fn.endswith('/') or fn.endswith('\\'):
                # A directory
                ensure_dir(fn)
            else:
                ensure_dir(dir)
                # Don't use read() to avoid allocating an arbitrarily large
                # chunk of memory for the file's content
                fp = zip.open(name)
                try:
                    with open(fn, 'wb') as destfp:
                        shutil.copyfileobj(fp, destfp)
                finally:
                    fp.close()
                    if zip_item_is_executable(info):
                        set_extracted_file_to_default_mode_plus_executable(fn)
    finally:
        zipfp.close()


def untar_file(filename, location):
    # type: (str, str) -> None
    """
    Untar the file (with path `filename`) to the destination `location`.
    All files are written based on system defaults and umask (i.e. permissions
    are not preserved), except that regular file members with any execute
    permissions (user, group, or world) have "chmod +x" applied after being
    written.  Note that for windows, any execute changes using os.chmod are
    no-ops per the python docs.
    """
    ensure_dir(location)
    if filename.lower().endswith('.gz') or filename.lower().endswith('.tgz'):
        mode = 'r:gz'
    elif filename.lower().endswith(BZ2_EXTENSIONS):
        mode = 'r:bz2'
    elif filename.lower().endswith(XZ_EXTENSIONS):
        mode = 'r:xz'
    elif filename.lower().endswith('.tar'):
        mode = 'r'
    else:
        logger.warning(
            'Cannot determine compression type for file %s', filename,
        )
        mode = 'r:*'
    tar = tarfile.open(filename, mode)
    try:
        leading = has_leading_dir([
            member.name for member in tar.getmembers()
        ])
        # Computed once: is_symlink_target_in_tar() would otherwise rebuild
        # it for every symlink member.
        member_paths = _tar_member_paths(tar)
        for member in tar.getmembers():
            fn = member.name
            if leading:
                # https://github.com/python/mypy/issues/1174
                fn = split_leading_dir(fn)[1]  # type: ignore
            path = os.path.join(location, fn)
            # The plain check rejects textual ".." escapes; resolving symlinks
            # also catches a later member redirected outside by an earlier
            # member's symlink (e.g. "link/../file").
            if not is_within_directory(location, path) or (
                not is_within_directory(location, path, resolve_symlinks=True)
            ):
                message = (
                    'The tar file ({}) has a file ({}) trying to install '
                    'outside target directory ({})'
                )
                raise InstallationError(
                    message.format(filename, path, location)
                )
            if member.isdir():
                ensure_dir(path)
            elif member.issym():
                # Reject symlinks resolving outside the destination, so a
                # later member cannot be written through them.
                link_target = os.path.join(
                    os.path.dirname(path), member.linkname
                )
                if not is_within_directory(
                    location, link_target, resolve_symlinks=True
                ):
                    message = (
                        'The tar file ({}) has a link ({}) trying to point '
                        'outside target directory ({})'
                    )
                    raise InstallationError(
                        message.format(filename, member.name, member.linkname)
                    )
                if not is_symlink_target_in_tar(tar, member, member_paths):
                    message = (
                        'The tar file ({}) has a link ({}) trying to point '
                        'outside target directory ({})'
                    )
                    raise InstallationError(
                        message.format(filename, member.name, member.linkname)
                    )
                try:
                    # https://github.com/python/typeshed/issues/2673
                    tar._extract_member(member, path)  # type: ignore
                except Exception as exc:
                    # Some corrupt tar files seem to produce this
                    # (specifically bad symlinks)
                    logger.warning(
                        'In the tar file %s the member %s is invalid: %s',
                        filename, member.name, exc,
                    )
                    continue
            else:
                try:
                    fp = tar.extractfile(member)
                except (KeyError, AttributeError) as exc:
                    # Some corrupt tar files seem to produce this
                    # (specifically bad symlinks)
                    logger.warning(
                        'In the tar file %s the member %s is invalid: %s',
                        filename, member.name, exc,
                    )
                    continue
                ensure_dir(os.path.dirname(path))
                assert fp is not None
                with open(path, 'wb') as destfp:
                    shutil.copyfileobj(fp, destfp)
                fp.close()
                # Update the timestamp (useful for cython compiled files)
                # https://github.com/python/typeshed/issues/2673
                tar.utime(member, path)  # type: ignore
                # member have any execute permissions for user/group/world?
                if member.mode & 0o111:
                    set_extracted_file_to_default_mode_plus_executable(path)
    finally:
        tar.close()


def unpack_file(
        filename,  # type: str
        location,  # type: str
        content_type=None,  # type: Optional[str]
):
    # type: (...) -> None
    filename = os.path.realpath(filename)

    # CVE-2026-3219: choose the archive format by decreasing reliability
    # (content-type, then filename extension, then magic signature) and only
    # trust the magic signature when it is unambiguous. The previous logic ran
    # ``zipfile.is_zipfile`` for any unrecognised name; since that scans for a
    # ZIP end-of-central-directory record anywhere in the file, a tar+ZIP
    # polyglot (e.g. a ZIP appended to a valid ``.tar.gz``) was always treated
    # as a ZIP regardless of its name.
    def _unzip():
        # type: () -> None
        unzip_file(filename, location, flatten=not filename.endswith('.whl'))

    def _untar():
        # type: () -> None
        untar_file(filename, location)

    if content_type == 'application/zip':
        return _unzip()
    if content_type == 'application/x-gzip':
        return _untar()

    if filename.lower().endswith(ZIP_EXTENSIONS):
        return _unzip()
    if filename.lower().endswith(
        TAR_EXTENSIONS + BZ2_EXTENSIONS + XZ_EXTENSIONS
    ):
        return _untar()

    # Fall back to magic signatures, but refuse the ambiguous case where the
    # file is simultaneously a valid ZIP and a valid tar.
    is_zip = zipfile.is_zipfile(filename)
    is_tar = tarfile.is_tarfile(filename)
    if is_zip and not is_tar:
        return _unzip()
    if is_tar and not is_zip:
        return _untar()
    if is_zip and is_tar:
        logger.critical(
            'Cannot unpack file %s (downloaded from %s, content-type: %s); '
            'it is ambiguously both a zip and a tar archive',
            filename, location, content_type,
        )
        raise InstallationError(
            'Ambiguous archive format (both zip and tar) of {}'.format(
                location
            )
        )

    # FIXME: handle?
    # FIXME: magic signatures?
    logger.critical(
        'Cannot unpack file %s (downloaded from %s, content-type: %s); '
        'cannot detect archive format',
        filename, location, content_type,
    )
    raise InstallationError(
        'Cannot determine archive format of {}'.format(location)
    )
